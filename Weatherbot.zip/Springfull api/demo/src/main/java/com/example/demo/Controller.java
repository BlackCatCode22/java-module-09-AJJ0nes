package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonElement;
import com.google.gson.stream.JsonReader;
import com.google.gson.JsonSyntaxException;

@RestController
public class Controller {

    // FIX: Updated User-Agent to avoid 403 Forbidden error from Nominatim.
    // NWS and Nominatim require a descriptive User-Agent.
    private static final String USER_AGENT = "SpringWeatherService/2.0_CanvasDemo (support@google.com)";
    private static final int MAX_RETRIES = 3;
    private static final long RETRY_DELAY_MS = 1000;

    // Helper to safely get a String from a JsonObject, or a default value
    private String safeGetString(JsonObject json, String key, String defaultValue) {
        return json != null && json.has(key) && !json.get(key).isJsonNull()
                ? json.get(key).getAsString()
                : defaultValue;
    }

    // Helper to safely get an Int from a JsonObject, or a default value
    private int safeGetInt(JsonObject json, String key, int defaultValue) {
        return json != null && json.has(key) && !json.get(key).isJsonNull()
                ? json.get(key).getAsInt()
                : defaultValue;
    }

    @GetMapping("/api/WeatherService")
    public String callWeatherService(@RequestParam String city) {
        // NOTE: This assumes the 'gson' dependency is configured in your build file (pom.xml or build.gradle).

        try {
            HttpClient client = HttpClient.newHttpClient();

            // --- STEP 0: Get coordinates via Nominatim (with Retry Logic) ---
            String encodedCity = URLEncoder.encode(city + ", USA", StandardCharsets.UTF_8);
            String geocodeUrl = "https://nominatim.openstreetmap.org/search?q=" + encodedCity + "&format=json&limit=1";

            HttpResponse<String> geocodeResponse = null;
            String body = "";
            boolean success = false;

            for (int attempt = 1; attempt <= MAX_RETRIES; attempt++) {
                HttpRequest geocodeRequest = HttpRequest.newBuilder()
                        .uri(new URI(geocodeUrl))
                        .header("User-Agent", USER_AGENT)
                        .build();

                System.out.println("Attempting geocode for " + city + " (Attempt " + attempt + ")...");
                geocodeResponse = client.send(geocodeRequest, HttpResponse.BodyHandlers.ofString());
                body = geocodeResponse.body().trim();

                // Success condition: Status 200 and a non-empty, non-empty-array body
                if (geocodeResponse.statusCode() == 200 && !body.isEmpty() && !body.equals("[]")) {
                    success = true;
                    break;
                }

                // Log non-200 status for debugging
                if (geocodeResponse.statusCode() != 200) {
                    System.err.println("Nominatim attempt " + attempt + " failed with status: " + geocodeResponse.statusCode());
                }

                // If failed and not the last attempt, wait before retrying
                if (attempt < MAX_RETRIES) {
                    Thread.sleep(RETRY_DELAY_MS);
                }
            }

            if (!success) {
                // Return the final failed status code to the user
                return "Geolocation failed for " + city + ". City not found or service unavailable after " + MAX_RETRIES + " attempts (Status: " + geocodeResponse.statusCode() + ").";
            }

            // Safer parsing for the Nominatim array response
            JsonArray geoResults;
            try (JsonReader reader = new JsonReader(new java.io.StringReader(body))) {
                reader.setLenient(true);
                geoResults = JsonParser.parseReader(reader).getAsJsonArray();
            } catch (JsonSyntaxException e) {
                return "Error processing geolocation data.";
            }

            if (geoResults.isEmpty()) {
                return "City not found: " + city + ". Please enter a valid US city.";
            }

            JsonObject location = geoResults.get(0).getAsJsonObject();
            // Use safeGetString for robust extraction
            double lat = Double.parseDouble(safeGetString(location, "lat", "0"));
            double lon = Double.parseDouble(safeGetString(location, "lon", "0"));

            // --- STEP 1: Get point metadata from NWS ---
            String pointUrl = String.format("https://api.weather.gov/points/%.4f,%.4f", lat, lon);

            HttpRequest pointRequest = HttpRequest.newBuilder()
                    .uri(new URI(pointUrl))
                    .header("User-Agent", USER_AGENT)
                    .build();

            HttpResponse<String> pointResponse = client.send(pointRequest, HttpResponse.BodyHandlers.ofString());

            if (pointResponse.statusCode() != 200) {
                return "NWS point service failed with status: " + pointResponse.statusCode();
            }

            JsonObject pointJson = JsonParser.parseString(pointResponse.body()).getAsJsonObject();

            // Safely check for 'properties' before attempting to access it
            if (!pointJson.has("properties") || pointJson.get("properties").isJsonNull()) {
                return "NWS response missing properties for grid data.";
            }

            JsonObject props = pointJson.getAsJsonObject("properties");

            // Use safeGetString/safeGetInt for robust extraction of grid data
            String office = safeGetString(props, "gridId", null);
            int gridX = safeGetInt(props, "gridX", -1);
            int gridY = safeGetInt(props, "gridY", -1);

            if (office == null || gridX == -1 || gridY == -1) {
                return "Could not determine NWS forecast office for " + city + ".";
            }

            // --- STEP 2: Get forecast ---
            String forecastUrl = String.format(
                    "https://api.weather.gov/gridpoints/%s/%d,%d/forecast",
                    office, gridX, gridY
            );

            HttpRequest forecastRequest = HttpRequest.newBuilder()
                    .uri(new URI(forecastUrl))
                    .header("User-Agent", USER_AGENT)
                    .build();

            HttpResponse<String> forecastResponse = client.send(forecastRequest, HttpResponse.BodyHandlers.ofString());

            if (forecastResponse.statusCode() != 200) {
                return "NWS forecast service failed with status: " + forecastResponse.statusCode();
            }

            JsonObject forecastJson = JsonParser.parseString(forecastResponse.body()).getAsJsonObject();

            // Safely check for the forecast periods array
            JsonElement periodsElement = forecastJson.has("properties") && !forecastJson.getAsJsonObject("properties").isJsonNull()
                    ? forecastJson.getAsJsonObject("properties").get("periods")
                    : null;

            if (periodsElement == null || !periodsElement.isJsonArray()) {
                return "NWS forecast data structure is invalid.";
            }

            JsonArray periods = periodsElement.getAsJsonArray();

            // --- STEP 3: Build output text with improved formatting ---
            StringBuilder output = new StringBuilder();
            output.append("========================================\n");
            output.append("Weather Forecast for ").append(city).append("\n");
            output.append("========================================\n\n");

            for (JsonElement period : periods) {
                JsonObject p = period.getAsJsonObject();

                // Period Name Header
                output.append("--- ").append(safeGetString(p, "name", "N/A")).append(" ---\n");

                // Temperature
                output.append("  Temp: ").append(safeGetInt(p, "temperature", 0))
                        .append(" ").append(safeGetString(p, "temperatureUnit", "U")).append("\n");

                // Wind
                output.append("  Wind: ").append(safeGetString(p, "windSpeed", "N/A"))
                        .append(" ").append(safeGetString(p, "windDirection", "N/A")).append("\n");

                // Detailed Forecast
                output.append("  Details: ").append(safeGetString(p, "detailedForecast", "Details unavailable.")).append("\n\n");
            }

            output.append("========================================");

            return output.toString();

        } catch (InterruptedException e) {
            // Re-interrupt the thread if it was interrupted while sleeping
            Thread.currentThread().interrupt();
            return "Internal process interrupted.";
        } catch (Exception e) {
            // Catch all exception block, logging the error for debugging.
            System.err.println("Critical Error during API processing:");
            e.printStackTrace();
            return "A critical internal error occurred while fetching the weather: " + e.getMessage();
        }
    }
}